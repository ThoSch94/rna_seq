library(testthat)
library(RiboseQC)

test_check("RiboseQC")
